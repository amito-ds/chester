from chester.zero_break.problem_specification import DataInfo


class FeatureStatistics:
    def __init__(self, data_info: DataInfo):
        self.data_info = data_info

    def calculate_stats(self):
        pass
