ner_model_path = '/Users/amitosi/opt/anaconda3/envs/py39/lib/python3.9/site-packages/en_core_web_md/en_core_web_md-3.3.0'
