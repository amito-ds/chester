def get_or_else(a, b):
    if a is not None:
        return a
    else:
        return b
