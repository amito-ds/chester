# goal: input to image
from PIL import Image
import numpy as np
#
# from diamond.image_caption.utils import *
#
# paths = ["/Users/amitosi/PycharmProjects/chester/chester/data/weather/sunrise336.jpg",
#          "/Users/amitosi/PycharmProjects/chester/chester/data/weather/rain118.jpg"]
# images = load_images_from_path(paths)
# numpy_images = [load_from_numpy(image) for image in images]
# # img_np = np.array(image)
# images = load_images_from_numpy(numpy_images)
# preidictions = predict_caption(images)
# print(preidictions)
