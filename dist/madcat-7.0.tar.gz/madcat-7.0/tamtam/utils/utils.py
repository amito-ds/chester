def true_if_exists(x):
    return False if not x else True
