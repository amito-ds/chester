def meir():
    return 10
