class Columns:
    weight = '_weight'
    id = '_ids'
