


# if __name__ == "__main__":
#     df1 = load_data_pirates().assign(target='chat_logs')
#     full_text = '. '.join(df1.text.to_list())
#     rake = RakeKeywordExtractor()
#     keywords = rake.extract(full_text, incl_scores=True)
#     print(keywords)
