from data_loader.aaa.bbb import meir

a = meir()
print("meir value", a)
